import * as THREE from 'three'
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';



// Scene
const scene = new THREE.Scene()


// Object
const geometry = new THREE.BoxGeometry(1, 1, 1)
const material = new THREE.MeshStandardMaterial({ color: 0x0000ff})
const mesh = new THREE.Mesh(geometry, material)
scene.add(mesh)


//Light
const ambientLight = new THREE.AmbientLight( 0xffffff, 0.3 );
scene.add( ambientLight );
const directionalLight = new THREE.DirectionalLight( 0xffffff, 0.5 );
scene.add( directionalLight );


// Sizes
const sizes = {
    width: window.innerWidth,
    height: window.innerHeight
}


//Resize
window.addEventListener('resize', () =>
{
    // Update sizes
    sizes.width = window.innerWidth
    sizes.height = window.innerHeight

    //Update camera
    camera.aspect = sizes.width / sizes.height
    camera.updateProjectionMatrix()

    // Update renderer
    renderer.setSize(sizes.width, sizes.height)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))

})


// Camera
const camera = new THREE.PerspectiveCamera(75, sizes.width / sizes.height)
camera.position.z = 3
scene.add(camera)


// Renderer
const renderer = new THREE.WebGLRenderer({
    canvas: document.querySelector('canvas.webgl')
})
renderer.setSize(sizes.width, sizes.height)
renderer.render(scene, camera)


//Controls
const controls = new OrbitControls(camera, renderer.domElement)

const clock = new THREE.Clock()


//Animate
const tick = () => {

    const elapsedTime = clock.getElapsedTime() 

    //Update Cube rotate
    mesh.rotation.y = elapsedTime
    mesh.rotation.x = elapsedTime

    controls.update()

    //Render
    renderer.render(scene, camera)

    //Call the tick-function on each frame
    window.requestAnimationFrame(tick)
}

tick()
