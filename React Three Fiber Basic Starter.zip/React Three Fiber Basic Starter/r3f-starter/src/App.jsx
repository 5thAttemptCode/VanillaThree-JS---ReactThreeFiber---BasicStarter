import { useThree, extend, useFrame } from '@react-three/fiber'
import { useRef } from 'react'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'

extend({ OrbitControls })

export default function App() {

  const { camera, gl } = useThree()
  const cubeRef = useRef()

  useFrame((state, delta) => {
    cubeRef.current.rotation.y += delta
  })

  return <>

    <orbitControls args={[ camera, gl.domElement ]} />

    <ambientLight />
    <directionalLight color="white" position={[0, 0, 5]} />

    <mesh ref={ cubeRef }>
      <boxGeometry />
      <meshStandardMaterial color="royalblue" />
    </mesh>
  </>
}

